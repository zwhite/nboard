README.txt

   iUI is a JavaScript and CSS package for developing WebApps for the iPhone.

   To install and use iUI, follow the instructions on the iUI Project Wiki:
   http://code.google.com/p/iui/wiki/Introduction
          
See also

   NOTICE.txt  - iUI credits and copyright notices
   LICENSE.txt - iUI licensing terms
